****************************************************************
* Ch13/14 - Panel data HOMEWORK
****************************************************************

******************************************
* QUESTION 1
* FE vs RE: Hausman and Mundlak tests
******************************************

/*

****************************
* Generate datasets 
****************************

* (corr --> FE), gamma=0 makes this a non-dynamic model, beta is coeff on X
drop _all
xtarsim Yit Xit Ui, n(200) t(5) gamma(0) beta(100) rho(.2) oneway(corr 1) sn(9) seed(1234)
save ".\data\Hausman_HW_1.dta", replace

* (rand --> RE), gamma=0 makes this a non-dynamic model, beta is coeff on X
drop _all
xtarsim Yit Xit Ui, n(100) t(10) gamma(0) beta(5) rho(0) oneway(rand 1) sn(9) seed(2345)
save ".\data\Hausman_HW_2.dta", replace

* (corr --> FE), gamma=0 makes this a non-dynamic model, beta is coeff on X
drop _all
xtarsim Yit Xit Ui, n(40) t(20) gamma(0) beta(10) rho(.1) oneway(corr 1) sn(9) seed(3456)
save ".\data\Hausman_HW_3.dta", replace

* (rand --> RE), gamma=0 makes this a non-dynamic model, beta is coeff on X
drop _all
xtarsim Yit Xit Ui, n(30) t(12) gamma(0) beta(2) rho(.4) oneway(rand 1) sn(9) seed(4567)
save ".\data\Hausman_HW_4.dta", replace
*/

forvalues i = 1/4{
	use ".\data\Hausman_HW_`i'.dta", clear
	quietly xtreg Y X*, re
	estimates store re
	quietly xtreg Y X*, fe
	estimates store fe
	hausman fe re, sigmamore
}



******************************************
* QUESTION 2
* Blundell Blond system GSS
******************************************

webuse abdata, clear
xtabond2 n nL1 w wL1 k kL1 yr*, gmm(nL1 wL1 kL1) iv(yr*) robust small noleveleq
xtabond2 n nL1 w wL1 k kL1 yr*, gmm(nL1 wL1 kL1) iv(yr*) robust small h(1)





******************************************
* QUESION 3
* Abond on Thomson data
******************************************

clear all
set more off
use ".\data\Thomson2017.dta", replace

* GMM 6
xtabond2 lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t , ///
    gmm(L.lnRnD L.lnValueAdded L.lnTaxPrice, laglimit(. 3) collapse) ///
	iv(i.t) twostep orthog robust 
estimates store GMM6

* GMM 7 (ie without collapse)
xtabond2 lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t , gmm(L.lnRnD L.lnValueAdded L.lnTaxPrice, laglimit(. 3)) iv(i.t) twostep orthog robust 
estimates store GMM7

* GMM 8 (ie without lag limits)
xtabond2 lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t , gmm(L.lnRnD L.lnValueAdded L.lnTaxPrice, collapse) iv(i.t) twostep orthog robust 
estimates store GMM8

* GMM 9 (ie without neither collapse nor lag limits)
xtabond2 lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t , gmm(L.lnRnD L.lnValueAdded L.lnTaxPrice) iv(i.t) twostep orthog robust 
estimates store GMM9

* Summary of results
estimates table GMM6 GMM7 GMM8 GMM9 , b(%6.3g) se(%7.4f)  drop(i.t _cons) stats(N)






******************************************
* UNIT ROOT QUESTIONS
*****************************

* QUESTION 4 
use ".\data\PanelUnitRoot.dta", clear
xtunitroot llc Y if EU==1, trend lags(aic 5) 


* QUESTION 5 
use ".\data\PanelUnitRoot.dta", clear
xtunitroot llc Y if EU==1, trend lags(aic 5) demean 


* QUESTION 6
use ".\data\PanelUnitRoot.dta", clear
xtunitroot llc Y if SAmer==1, trend lags(aic 8)
xtunitroot ips Y if SAmer==1, trend lags(aic 8)
xtunitroot hadri Y if SAmer==1, trend robust





*************************************
* QUESTION 7, XTCIPS 
*************************************

/*

************************
* Create Dataset
************************

* PA.NUS                     Exchange rate (LCU per US$, period average)
* PA.NUS.FCRF                Official exchange rate (LCU per US$, period average)
* PE.NUS.FCAE                Official exchange rate (LCU per US$, end period)

wbopendata, indicator(pa.nus.fcrf) long clear

keep if countryname == "Canada" 	| countryname == "Australia"  | /// 
		countryname == "New Zealand"| countryname == "Austria"  | /// 
		countryname == "Belgium"  	| countryname == "Denmark"  | /// 
		countryname == "Finland"  	| countryname == "France"  | /// 
		countryname == "Germany"  	| countryname == "Ireland"  | /// 
		countryname == "Italy"  	| countryname == "Netherlands"  | /// 
		countryname == "Norway"  	| countryname == "Spain"  | /// 
		countryname == "Sweden"  	| countryname == "Switzerland"  | /// 
		countryname == "United Kingdom"  | countryname == "Japan"  | /// 
		countryname == "Korea"  	| countryname == "Singapore"  | /// 
		countryname == "Thailand"

keep if year >= 1974 & year <= 1997

encode countryname, generate(i)
xtset i year

drop country* region* admin* income* lending*
rename pa_nus_fcrf XR
label variable XR "Official exchange rate (LCU per US$, period average)"
gen lnXR = log(XR)

save ".\data\lnXRdata.dta", replace
*/


* Cross-sectional IPS test of the PPP hypothesis.
use ".\data\lnXRdata.dta", clear
xtcips lnXR, maxlags(5) bglags(1) trend
xtcips lnXR, maxlags(5) bglags(1) 
xtunitroot ips lnXR, lags(aic 5)


 
***********************
* Panel VAR Homework problems
***********************

use ".\data\panelVAR.dta," clear

* QUESTION 8
* Using an ISP test and xtunitroot, verify that GDP and CO2 are stationary.
xtunitroot ips pctGDP, lags(2) /*stationary at 0.10 and 0.05*/
xtunitroot ips pctCO2, lags(2) /*stationary at all levels*/


* QUESTION 9
xtunitroot llc pctGDP, lags(2) /*stationary at 0.10 and 0.05*/
xtunitroot llc pctCO2, lags(2) /*stationary at all levels*/

* QUESTION 10
* Re-estimate the panel VAR on GDP and CO`2, but estimate a 2-lag model. 
* Keep the same instrumentation. Does GDP Granger-cause CO2? Does CO2 Granger-cause GDP?
pvar pctGDP pctCO2 , lags(2) instlags(1/4)
pvargranger
* SOL: GDP Granger-causes CO2 at all levels.

* QUESTION 11
* Re-estimate the panel VAR on GDP and CO2, but estimate a 1-lag model. 
* Keep the same instrumentation. Does GDP Granger-cause CO2? Does CO2 Granger-cause GDP?
pvar pctGDP pctCO2 , lags(1) instlags(1/4)
pvargranger
* SOL: CO2 Granger-causes GDP at the 0.10 level, but not at 0.05 or 0.01 level.

* QUESTION 12
* Re-estimate the panel VAR on GDP and CO2. But with the following modifications:
pvarsoc pctGDP pctCO2 , maxlag(4) pvaropts(instlags(4/7)) /* Optimal lag = 2 for all IC*/
pvar pctGDP pctCO2 , lags(2) instlags(4/7)
pvarstable /* Eigenvalues are dangerously close to one. Near unit roots. We're on the safe side, though.*/
pvargranger /* GDP causes CO2 at all levels. CO2 granger-causes GDP at the 0.10 and 0.05 levels, but not at the 0.01 level.*/










* QUESTION 13
* Cointegration Homework
	xtreg CO2pc GDPpc, fe
	xtcsd, pesaran
	xtcointtest pedroni CO2pc GDPpc, lags(aic 2) ar(same) demean





	
	
	
	
	
	
	
	
	



