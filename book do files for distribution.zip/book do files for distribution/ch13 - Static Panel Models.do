*************************************************************
* Chapter 13 - Static Panel Data Models
*************************************************************


*****************************************
* Figure 13.1: Examples of Stationary Panel Data
*****************************************

capture ssc install xtarsim
drop _all
set scheme s1mono
cd "C:\Users\johnlevendis\Google Drive\papers\book\panel_data\"

* Independent series, no FEs, same mean
xtarsim  y x FEs, n(4) t(20) beta(1) gamma(0) rho(.10) sn(5) seed(124) one(rand 1)
xtline y, overlay legend(off) xtitle(time) ytitle(Y) ylabel(none) ytitle("") name("PanelExample01", replace)

* FEs: country-specific intercepts
xtarsim  y x FEs, n(4) t(20) beta(1) gamma(0) rho(.10) sn(5) seed(12344) one(rand 25)
xtline y, overlay legend(off) xtitle(time) ytitle(Y) ylabel(none) ytitle("") name("PanelExample02", replace)

* FEs: time-specific intercepts
*xtarsim  y x FEs TFEs, n(4) t(20) beta(1) gamma(0) rho(.10) sn(5) seed(12344) two(rand 5)
*xtline y, overlay legend(off) xtitle(time) ytitle(Y) ylabel(none) ytitle("")

xtarsim  y x FEs TFEs, n(4) t(20) beta(1) gamma(0) rho(.10) sn(5) seed(54321) two(rand 5)
xtline y, overlay legend(off) xtitle(time) ytitle(Y) ylabel(none) ytitle("") name("PanelExample03", replace)

* Both time-FE and country-FEs:
xtarsim  y x FEs TFEs, n(4) t(20) beta(1) gamma(0) rho(.10) sn(5) seed(12344) two(rand 5)
replace y = y+10*ivar
xtline y, overlay legend(off) xtitle(time) ytitle(Y) ylabel(none) ytitle("") name("PanelExample04", replace)

graph combine  PanelExample01 PanelExample02 PanelExample03 PanelExample04, cols(2)
graph export "Graphs\PanelExamples.pdf", as(pdf)  replace




*****************************************
* 13.2 Formatting the data
*****************************************

* Wide
wbopendata, indicator(NY.GDP.MKTP.CD) clear 
sort countryname
replace yr2018 = yr2018/1000000000000
replace yr2019 = yr2019/1000000000000
replace yr2020 = yr2020/1000000000000
rename countryname country
keep if (country == "France" | country == "Germany" | country == "Spain"| country == "Italy") 
keep country yr2018-yr2020
rename yr2018 GDP2018
rename yr2019 GDP2019
rename yr2020 GDP2020
list, noobs

* Long
wbopendata, indicator(NY.GDP.MKTP.CD) clear long
rename ny GDP
replace GDP = GDP/1000000000000
sort countryname year
rename countryname country
keep if (country == "France" | country == "Germany" | country == "Spain"| country == "Italy")
keep if (year >= 2018 & year <= 2020)
list country year GDP , noobs sepby(country)
keep country year GDP
encode country, gen(icode)
xtset icode year
drop country
rename icode country
save ".\data\xtGDPlong.dta", replace

* Reshape
use ".\data\xtGDPlong.dta", clear
list, noobs sepby(country)
reshape wide GDP, i(country) j(year)
list, noobs
reshape long
list, noobs sepby(country)



*****************************************
* 13.3.4 First-differencing
*****************************************

use ".\data\xtGDPlong.dta", clear
gen FirstDiffGDP = D.GDP 
list country year GDP FirstDiffGDP, noobs sepby(country)





*****************************************
* 13.4.4 Two equivalent ways of estimating FE models
*****************************************

drop _all
clear all
xtarsim  y x FEs, n(4) t(10) beta(1) gamma(0) rho(.10) sn(5) seed(12344) one(rand 25)
drop FEs
rename ivar country
rename tvar t
sum
save ".\data\FEequivalence.dta", replace

use ".\data\FEequivalence.dta", clear
quietly xtreg y x, fe 
estimates store FEa

quietly reg y x i.country
estimates store FEb

estimates table FEa FEb, t(%9.7f)






*****************************************
* 13.5 Choosing between RE and FE models
*****************************************

drop _all
clear
set obs 20
set seed 1234

* Make time-invariant country-varying data
	generate i  = _n
	generate t  = 1
	generate nu = rnormal()
	generate u_re = rnormal()	/* u1 is uncorrelated with X */
	generate u_fe = nu 			/* u2 is correlated with X */

* Add a time dimension 
	expand 10
	bysort i:  replace t = _n
	xtset i t, yearly
	generate X = runiform(0,100) + 50*nu /* time-varying regressor, correlated to u_fe via nu*/

* Generate Y's from RE and FE processes
	generate epsilon = rnormal()
	generate Y_re  = 1*X + u_re + epsilon /* Y from RE DGP */
	generate Y_fe  = 1*X + u_fe + epsilon /* Y from FE DGP */
	
* Save dataset
save ".\data\HausmanMundlak.dta", replace


**********************
* Hausman on FE data
**********************	
use ".\data\HausmanMundlak.dta", clear
quietly xtreg Y_fe X, re 
estimates store m1
quietly xtreg Y_fe X, fe 
estimates store m2
estimates table m1 m2
hausman m2 m1, sigmamore	

**********************
* Hausman on RE data
**********************
quietly xtreg Y_re X, re
estimates store m3 
quietly xtreg Y_re X, fe 
estimates store m4
estimates table m3 m4
hausman m4 m3, sigmamore


**********************
* Mundlak on FE data
**********************	
bysort i: egen double meanX = mean(X)
quietly xtreg Y_fe X meanX
test meanX


**********************
* Mundlak on RE data
**********************	
quietly xtreg Y_re X meanX
test meanX




*****************************************
* 13.5.3 You must estimate the correct model
*****************************************

drop _all
program drop _all
set seed 12345

program define REvsFE, rclass                 

drop _all
clear
set obs 20

* Make time-invariant country-varying data
	generate i  = _n
	generate t  = 1
	generate nu = rnormal()
	generate u_re = rnormal()	/* u1 is uncorrelated with X */
	generate u_fe = nu 			/* u2 is correlated with X */

* Add a time dimension 
	expand 10
	bysort i:  replace t = _n
	xtset i t, yearly
	generate X = runiform(0,100) + 50*nu /* time-varying regressor, correlated to u_fe via nu*/

* Generate Y's from RE and FE processes
	generate epsilon = rnormal()
	generate Y_re  = 1*X + u_re + epsilon /* Y from RE DGP */
	generate Y_fe  = 1*X + u_fe + epsilon /* Y from FE DGP */

* Estimating RE models
xtreg Y_re X*, re 
	return scalar RERE  = _b[X]
xtreg Y_fe X*, re 
	return scalar FERE = _b[X]

* Estimating FE models
xtreg Y_re X*, fe
	return scalar REFE = _b[X]
xtreg Y_fe X*, fe 
	return scalar FEFE = _b[X]

end

simulate REdataREmodel = r(RERE) FEdataREmodel = r(FERE) ///
         REdataFEmodel = r(REFE) FEdataFEmodel = r(FEFE) ///
		 , reps(3000): REvsFE
summarize

twoway 	(kdensity REdataREmodel, lpattern(longdash)) ///
		(kdensity FEdataREmodel, lpattern(solid)) ///
		(kdensity REdataFEmodel, lpattern(dash)) ///
		(kdensity FEdataFEmodel, lpattern(dash)),  ///
		legend(	label(1 "RE Data, RE Estimator")  ///
				label(2 "FE Data, RE Estimator")  ///
				label(3 "RE Data, FE Estimator")  ///
				label(4 "FE Data, FE Estimator")) ///
		scheme(s1mono) xtitle("Estimated Coefficients (true=1.0)")

		
graph export ".\graphs\REvsFE.pdf", as(pdf) replace



*****************************************
* Figure 13.3: European Countries Exhibit Simultaneous Shocks
*****************************************

wbopendata, indicator(NY.GDP.MKTP.KN) clear long /*In Eur, the common shock is Covid-19 */
rename ny GDP
keep if (countryname == "France" | countryname == "Germany" | countryname == "Spain"| countryname == "Italy") 
keep if year >= 2000 & year <= 2023
sort countryname year
encode countryname, generate(ccode) 
xtset ccode year
keep GDP ccode year countryname
replace GDP = GDP/1000000000000
label var GDP "GDP in trillions of Euros"

twoway (connected GDP year if country == "Germany", lpattern(solid) msymbol(none)) ///
	(connected GDP year if country == "France", lpattern(dash) msymbol(none))  ///
	(connected GDP year if country == "Italy", lpattern(shortdash) msymbol(none)) ///
	(connected GDP year if country == "Spain", lpattern(longdash) msymbol(none)) ///
	, legend(label(1 "Germany") label(2 "France") label(3 "Italy") label(4 "Spain") ) ///
	xtitle("") note("Source: World Bank, indicator NY.GDP.MKTP.KN") 
graph export ".\graphs\PanelXTdependence.pdf", as(pdf)  replace	



*****************************************
* 13.6.2 Estimating FE regressions With Time-Dummies in Stata
*****************************************

use ".\data\Thomson2017.dta", clear

* LSDV
reg lnRnD L.lnValueAdded L.lnTaxPrice i.t i.i
estimates store LSDV

* FE
xtreg lnRnD L.lnValueAdded L.lnTaxPrice i.t, fe 
estimates store FE

estimates table LSDV FE, drop(i.i) t(%9.7f)




*****************************************
* 13.7.1 Driscoll-Kraay Standard Errors
*****************************************

* Generate Driscoll-Kraay data

		capture ssc install xtarsim

		* FEs: country-specific intercepts
		xtarsim  y x FEs     , n(10) t(5) beta(1) gamma(0) rho(0) sn(5) seed(12344) one(rand 1)
		gen TFEs = 0
		save ".\data\CSD_temp1.dta", replace

		* FEs: time-specific intercepts
		xtarsim  y x FEs TFEs, n(10) t(5) beta(1) gamma(0) rho(0) sn(5) seed(54321) two(rand 1)
		replace ivar = 10+ivar
		save ".\data\CSD_temp2.dta", replace

		append using ".\data\CSD_temp1.dta"
		sort ivar
		xtset ivar tvar
		save ".\data\DKraay.dta", replace

		capture erase ".\data\CSD_temp1.dta"
		capture erase ".\data\CSD_temp2.dta"

use ".\data\DKraay.dta", clear
xtreg y x, fe
xtscc y x, fe




*****************************************
* 13.7.3 Testing for CSD in Stata
*****************************************


webuse abdata, clear

quietly xtreg n L(0/1).(w k ys) , cluster(id) fe 
xtcsd, pesaran 
xtcsd, friedman
xtcsd, frees 



*****************************************
* 13.7.4 Lagrange Multiplier CSD Test
*****************************************


xtarsim y x eta, n(20) t(5) g(0) beta(1) rho(0.20) ///
     one(corr 1) sn(9) seed(1234)
quietly xtreg y x, fe 
xttest2





