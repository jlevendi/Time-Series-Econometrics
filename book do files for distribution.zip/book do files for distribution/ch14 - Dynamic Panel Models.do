*************************************************************
* Chapter 14 - Dynamic Panel Data Models
*************************************************************


*****************************************
* 14.0.1 Dynamic Panel Bias
*****************************************

program drop _all
set seed 12345

program define DPDbias, rclass                 
	forvalues t = 5(45)50{
		
		local beta  = 1
		local gamma = 0.30

		* Generate the data:
		xtarsim  y x z, n(100) t(`t') beta(`beta') gamma(`gamma') rho(.10) sn(5) one(corr 3)

		* XTREG_FE
		xtreg y L.y x, fe
		mat coeffs=e(b)
		return scalar gamma_fe_`t' = coeffs[1,1]               
		return scalar beta_fe_`t'  = coeffs[1,2] 

		* XTABOND2 GMM-SYS
		* system GMM is the default (we did not specify 'noleveleq' as an option, so it automaticall includes the levels-equation making it SYS-GMM)
		xtabond2 y L.y x, gmm(L.y x) small
		mat coeffs=e(b)
		return scalar gamma_ab1_`t' = coeffs[1,1] 
		return scalar beta_ab1_`t'  = coeffs[1,2] 

		* XTABOND2 - GMM-SYS, collapsed
		* system GMM is the default (we did not specify 'noleveleq' as an option, so it automaticall includes the levels-equation making it SYS-GMM)
		xtabond2 y L.y x, gmm(L.y x, collapse) small
		mat coeffs=e(b)
		return scalar gamma_ab2_`t' = coeffs[1,1] 
		return scalar beta_ab2_`t'  = coeffs[1,2] 

		* XTABOND2 - GMM-SYS, lag-limited
		* system GMM is the default (we did not specify 'noleveleq' as an option, so it automaticall includes the levels-equation making it SYS-GMM)
		xtabond2 y L.y x, gmm(L.y x, lag(1 1)) small
		mat coeffs=e(b)
		return scalar gamma_ab3_`t' = coeffs[1,1] 
		return scalar beta_ab3_`t'  = coeffs[1,2] 
		
		}
end

simulate ///
	gamma_fe_5   =r(gamma_fe_5)   beta_fe_5   = r(beta_fe_5) ///
	gamma_fe_50  =r(gamma_fe_50)  beta_fe_50  = r(beta_fe_50) ///
	gamma_ab1_5  =r(gamma_ab1_5)  beta_ab1_5  = r(beta_ab1_5)  ///
	gamma_ab1_50 =r(gamma_ab1_50) beta_ab1_50 = r(beta_ab1_50) ///
	gamma_ab2_5  =r(gamma_ab2_5)  beta_ab2_5  = r(beta_ab2_5)  ///
	gamma_ab2_50 =r(gamma_ab2_50) beta_ab2_50 = r(beta_ab2_50) ///
 	gamma_ab3_5  =r(gamma_ab3_5)  beta_ab3_5  = r(beta_ab3_5)  ///
 	gamma_ab3_50 =r(gamma_ab3_50) beta_ab3_50 = r(beta_ab3_50) , reps(2000): DPDbias
	
	
save .\data\DPDbias.dta, replace

* Graphs and Tables
{
use .\data\DPDbias.dta, clear
sum, sep(3)     /* estimated bias as the sample mean of ee */

sum beta_fe*  beta_ab1*  beta_ab2*  beta_ab3*, sep(4)
sum gamma_fe* gamma_ab1* gamma_ab2* gamma_ab3*, sep(4)

* FE estimates of GAMMA=.30, as t increases
twoway 	(kdensity gamma_fe_5, lpattern(dash))  (kdensity gamma_fe_50, lpattern(solid) xtitle("Estimated {&gamma}") ), ///
		legend(label(1 "T=5")                  label(2 "T=50") ///
		pos(10) ring(0) col(1) region(lwidth(none)) ) scheme(s1mono) 
		graph export "Graphs\DPDbiasGamFE.pdf", as(pdf) replace
		
* Arellano-Bond gmm estimates of GAMMA=.30, as t increases
twoway 	(kdensity gamma_ab1_5, lpattern(dash))   (kdensity gamma_ab1_50, lpattern(solid) xtitle("Estimated {&gamma}") ), ///
		legend(label(1 "T=5")                    label(2 "T=50") ///
		pos(10) ring(0) col(1) region(lwidth(none)) ) scheme(s1mono) 
		graph export "Graphs\DPDbiasGamAB.pdf", as(pdf) replace

* Arellano-Bond gmm COLLAPSED estimates of GAMMA=.30, as t increases
twoway 	(kdensity gamma_ab2_5, lpattern(dash))   (kdensity gamma_ab2_50, lpattern(solid) xtitle("Estimated {&gamma}") ), ///
		legend(label(1 "T=5")                    label(2 "T=50") ///
		pos(10) ring(0) col(1) region(lwidth(none)) ) scheme(s1mono) 
		graph export "Graphs\DPDbiasGamABcoll.pdf", as(pdf) replace
		
* Arellano-Bond gmm LAG-LIMITED estimates of GAMMA=.30, as t increases
twoway 	(kdensity gamma_ab3_5, lpattern(dash))   (kdensity gamma_ab3_50, lpattern(solid) xtitle("Estimated {&gamma}") ), ///
		legend(label(1 "T=5")                    label(2 "T=50") ///
		pos(10) ring(0) col(1) region(lwidth(none)) ) scheme(s1mono) 
		graph export "Graphs\DPDbiasGamLL.pdf", as(pdf) replace
	
* FE estimates of BETA=1.0, as t increases
twoway 	(kdensity beta_fe_5, lpattern(dash))  (kdensity beta_fe_50, lpattern(solid) xtitle("Estimated {&beta}") ), ///
		legend(label(1 "T=5")                 label(2 "T=50") pos(10) ring(0) col(1) region(lwidth(none)) ) ///
		scheme(s1mono) 
		graph export "Graphs\DPDbiasBetaFE.pdf", as(pdf) replace	

* Arellano-Bond gmm estimates of BETA=1.0, as t increases
twoway 	(kdensity beta_ab1_5, lpattern(dash))   (kdensity beta_ab1_50, lpattern(solid) xtitle("Estimated {&beta}") ), ///
		legend(label(1 "T=5")                   label(2 "T=50") pos(10) ring(0) col(1) region(lwidth(none)) ) ///
		scheme(s1mono) 	
		graph export "Graphs\DPDbiasBetAB.pdf", as(pdf) replace
		
* Arellano-Bond gmm COLLAPSED estimates of BETA=1.0, as t increases
twoway 	(kdensity beta_ab2_5, lpattern(dash))  	(kdensity beta_ab2_50, lpattern(solid) xtitle("Estimated {&beta}") ), ///
		legend(label(1 "T=5")                   label(2 "T=50") pos(10) ring(0) col(1) region(lwidth(none)) ) ///
		scheme(s1mono) 	
		graph export "Graphs\DPDbiasBetABcoll.pdf", as(pdf)  replace

* Arellano-Bond gmm LAG-LIMITED estimates of BETA=1.0, as t increases
twoway 	(kdensity beta_ab3_5, lpattern(dash))  	(kdensity beta_ab3_50, lpattern(solid) xtitle("Estimated {&beta}") ), ///
		legend(label(1 "T=5")                   label(2 "T=50") pos(10) ring(0) col(1) region(lwidth(none)) ) ///
		scheme(s1mono) 	
		graph export "Graphs\DPDbiasBetLL.pdf", as(pdf) replace
}
		



*****************************************
* 14.0.2 Replicating Arellano & Bond (1991)
*****************************************

capture ssc install xtabond2
webuse abdata, clear
xtset id year

* Pooled OLS
reg n nL1 nL2 w wL1 k kL1 kL2 ys ysL1 ysL2 yr*, cluster(id) 
estimates store PooledOLS

* FE (within estimator)
xtreg n nL1 nL2 w wL1 k kL1 kL2 ys ysL1 ysL2 yr*, cluster(id) fe 
estimates store FE

* Difference GMM
xtabond2 n nL1 nL2 w wL1 k kL1 kL2 ys ysL1 ysL2 yr*, ///
	gmmstyle(nL1) ivstyle(w wL1 k kL1 kL2 ys ysL1 ysL2 yr*) ///
	nolevel robust small
estimates store GMM_1

* Difference GMM
xtabond2 n nL1 nL2 w wL1 k kL1 kL2 ys ysL1 ysL2 yr*, gmmstyle(nL1) ivstyle(w wL1 k kL1 kL2 ys ysL1 ysL2 yr*) nolevel robust small twostep
estimates store GMM_2

xtabond2 n nL1 nL2 w wL1 k ys ysL1 yr*, gmmstyle(nL1) ivstyle(w wL1 k ys ysL1 yr*) nolevel robust small twostep
estimates store GMM_3


* Tables 4 and 5 in Arellano Bond (1991)
estimates table PooledOLS FE GMM_1 GMM_2 GMM_3, b(%7.3f) se(%7.3f)  keep(n* w* k* ys*)






*****************************************
* 14.0.3 Replicating Thomson (2017)
*****************************************

use ".data\Thomson2017.dta", clear

* FD
reg d.lnRnD ld.lnRnD ld.lnValueAdded ld.lnTaxPrice i.t, vce(cluster i)
gen fdsample = e(sample)
estimates store FD

* FE
xtreg lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t if fdsample, fe vce(cluster i)
estimates store FE

* GMM (4)
xtabond2 lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t if fdsample, gmm(L.lnRnD L.lnValueAdded L.lnTaxPrice, laglimit(. 3) collapse) iv(i.t) twostep orthog robust 
estimates store GMM4

* GMM (5) (manuf only)
xtabond2 lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t if fdsample & manuf == 1 , gmm(L.lnRnD L.lnValueAdded L.lnTaxPrice, laglimit(. 3) collapse) iv(i.t) twostep orthog robust 
estimates store GMM5

* GMM (6)
xtabond2 lnRnD L.lnRnD L.lnValueAdded L.lnTaxPrice i.t, gmm(L.lnRnD L.lnValueAdded L.lnTaxPrice, laglimit(. 3) collapse) iv(i.t) twostep orthog robust 
estimates store GMM6


estimates table FE FD GMM4 GMM5 GMM6 , b(%6.3g) se(%7.4f)  drop(i.t _cons) stats(N)





*****************************************
* 14.1 Stationarity and Panel Unit Root Tests
*****************************************


/*

******************************
* Create dataset
******************************

wbopendata, indicator(NY.GDP.PCAP.KN) long clear
drop if region == "" | region == "NA"
drop region adminregion adminregionname incomelevel incomelevelname lendingtype lendingtypename
rename ny_gdp_pcap_kn Y
label var Y "GDP per capita (constant LCU)"
encode countryname, generate(country) 
drop countrycode 
drop if year <= 1995
drop if Y == .

keep if ///
		countryname == "Austria" | countryname == "Belgium" 	| countryname == "Bulgaria" | ///
		countryname == "Croatia" | countryname == "Republic of Cyprus" 	| countryname == "Czech Republic" |  ///
		countryname == "Denmark" | countryname == "Estonia"		| countryname == "Finland"  |  ///
		countryname == "France"	 | countryname == "Germany"		| countryname == "Greece"	|  ///
		countryname == "Hungary" | countryname == "Ireland"		| countryname == "Italy"	|  ///
		countryname == "Latvia"	 | countryname == "Lithuania"	| countryname == "Luxembourg" |  ///
		countryname == "Malta"	 | countryname == "Netherlands"	| countryname == "Poland" |  ///
		countryname == "Portugal"| countryname == "Romania"		| countryname == "Slovakia" |  ///
		countryname == "Slovenia"| countryname == "Spain"		| countryname == "Sweden" | ///
		regionname == "Latin America and Caribbean"

drop if countryname == "Cayman Islands"
drop if countryname == "Sint Maarten (Dutch part)"
drop if countryname == "Turks and Caicos Islands"
drop if countryname == "Virgin Islands (US)"
drop if countryname== "Curacao"
drop if countryname == "Venezuela, RB"

gen EU = 0
replace EU = 1 if ///
		countryname == "Austria" | countryname == "Belgium" 	| countryname == "Bulgaria" | ///
		countryname == "Croatia" | countryname == "Republic of Cyprus" 	| countryname == "Czech Republic" |  ///
		countryname == "Denmark" | countryname == "Estonia"		| countryname == "Finland"  |  ///
		countryname == "France"	 | countryname == "Germany"		| countryname == "Greece"	|  ///
		countryname == "Hungary" | countryname == "Ireland"		| countryname == "Italy"	|  ///
		countryname == "Latvia"	 | countryname == "Lithuania"	| countryname == "Luxembourg" |  ///
		countryname == "Malta"	 | countryname == "Netherlands"	| countryname == "Poland" |  ///
		countryname == "Portugal"| countryname == "Romania"		| countryname == "Slovakia" |  ///
		countryname == "Slovenia"| countryname == "Spain"		| countryname == "Sweden"

gen SAmer = 0
replace SAmer = 1 if EU ==0

xtset country year

save ".\data\PanelUnitRoot.dta", replace
*/

use ".\data\PanelUnitRoot.dta", clear

* EXAMPLE
xtunitroot llc Y if EU==1, trend
xtunitroot ips Y if EU==1, trend lags(aic 5)
xtunitroot fisher Y if EU==1, trend lags(1) pperron
xtunitroot fisher Y if EU==1, trend lags(1) dfuller
xtfisher Y if EU==1, trend lags(1) pp 
xtfisher Y if EU==1, trend lags(1) 
xtunitroot ht Y if EU==1, trend
xtunitroot hadri Y if EU==1, trend robust




*****************************************
* 14.2 Structural Breaks
*****************************************


*******************************
* Figure 14.5: Two simpler examples of panel structural breaks
*******************************


		*******************************
		* Intercept changes
		*******************************

		drop _all
		set scheme s1mono

		local N = 3
		local T = 50
		local shift = 20
		local beta = 0.70

		set seed 20230311
		set obs `N'
		gen i = _n
		gen alpha = .
		replace alpha = 100 if i == 1
		replace alpha = 110 if i == 2
		replace alpha = 125 if i == 3

		expand `T'
		sort i
		gen t = .
		bysort i: replace t = _n
		xtset i t

		gen error = rnormal(0,.75)

		gen y = alpha + `beta'*t + error 	
		replace y = y + `shift' if t >  `T'/2

		xtline y, overlay legend(off) xtitle(time) ytitle(Y) ylabel(none) ytitle("") saving("xtStructBreak01", replace)
		* graph export xtStructBreak01.pdf, replace


		*******************************
		* Slope changes
		*******************************

		drop _all

		local N = 3
		local T = 50
		local shift = 20

		set seed 20230311
		set obs `N'
		gen i = _n
		gen alpha = .
		replace alpha = 100 if i == 1
		replace alpha = 110 if i == 2
		replace alpha = 125 if i == 3

		expand `T'
		sort i
		gen t = .
		bysort i: replace t = _n
		xtset i t

		gen error = rnormal(0,.75)

		gen TimeSince = 0
		replace TimeSince = t - 25 if t > (`T'/2)

		local beta1 = "0.5"
		local beta2 = "3"

		gen y = .
		replace y = error + alpha if t == 1
		replace y = alpha + `beta1'*t + (`beta2' - `beta1')*TimeSince + error in 2/L

		xtline y, overlay legend(off) xtitle(time) ytitle(Y) ylabel(none) ytitle("") saving("xtStructBreak02", replace)
		* graph export xtStructBreak02.pdf, replace





/*
*********************************
* Download and format the data
*********************************

drop _all
import fred CAUR TXUR NYUR FLUR PAUR OHUR MIUR MAUR ALUR COUR MNUR VAUR NCUR ORUR WIUR GAUR IAUR AZUR WAUR MOUR WVUR AKUR INUR NDUR SCUR OKUR TNUR ILUR NVUR UTUR NMUR LAUR CTUR KYUR ARUR KSUR MEUR HIUR NJUR MDUR WYUR MSUR RIUR MTUR NHUR NEUR IDUR SDUR DEUR VTUR, daterange(2000-01-01 2023-03-31) long clear

rename value UR
encode series_id, gen(state)
order series_id state datestr daten UR

generate datem = mofd(daten)
xtset state datem, monthly

gen year = year(daten)

gen lnUR = log(UR)
label var UR "Unemployment Rate"
label var lnUR "log of Unemployment Rate"

save ".\data\panelUNRATE.dta", replace

*/


*capture ssc install moremata
use ".\data\panelUNRATE.dta", clear
xtbreak estimate lnUR L.lnUR if year >= 2010 , breaks(1)




********************************
* Figure 14.6: State-level Unemployment Rates
********************************

use ".\data\panelUNRATE.dta", clear
set scheme s1mono
xtline lnUR if year >= 2010, overlay legend(off)
*graph export ".\graphs\xtbreak.pdf", as(pdf) replace






*****************************************************************
* 14.3 Panel VARs
*****************************************************************

********************************
* 14.3.1 Panel VAR Example
********************************

set scheme s1mono
set more off
capture ssc install xtvar
clear matrix
drop _all

* GDP and CO2 pollution
* NY.GDP.MKTP.KN -- GDP (constant LCU)
* EN.ATM.CO2E.KT -- CO2 emissions (kt)

* Use the original 11 euro countries, plus Greece (which joined shortly after):
wbopendata, indicator(NY.GDP.MKTP.KN ; EN.ATM.CO2E.KT) ///
	country(AUT;BEL;DEU;ESP;FIN;FRA;GRC;IRL;ITA;LUX;NLD;PRT) ///
	year(2001:2019) clear long 

encode countrycode, gen(i)
xtset i year

rename ny_gdp_mktp_kn GDP
rename en_atm_co2e_kt CO2

gen pctGDP = log(GDP) - log(L.GDP)
gen pctCO2 = log(CO2) - log(L.CO2)

save ".\data\panelVAR.dta", replace

pvarsoc pctGDP pctCO2 , maxlag(4) pvaropts(instlags(1/4))
pvar pctGDP pctCO2 , lags(3) instlags(1/4)
pvarstable
pvarirf, oirf mc(200)
* graph export "G:\My Drive\papers\book\panel_data\graphs\pVAROIRF.pdf", as(pdf) replace
pvargranger









*****************************************************************
* 14.4 Cointegration Tests
*****************************************************************

********************************
* 14.4.1 Cointegration Test Example: the Permanent Income Hypothesis
********************************

/*
*********************************
* Download and format the data
*********************************

wbopendata, indicator(NE.CON.TOTL.KN ; NY.GDP.MKTP.KN ; SP.POP.TOTL; EN.ATM.CO2E.KT) ///
   country(AUT;BEL;DEU;ESP;FIN;FRA;GRC;IRL;ITA;LUX;NLD;PRT) ///
   year(2001:2019) clear long

* NE.CON.TOTL.KN -- Final consumption expenditure (constant LCU)
* NY.GNY.TOTL.KN -- Gross national income (constant LCU)
* NY.GDP.MKTP.KN -- GDP (constant LCU)
* SP.POP.TOTL    -- Population, total
* EN.ATM.CO2E.KT -- Co2 emissions (kt)

encode countrycode, gen(icode)
xtset icode year

rename ne_con_totl_kn C
rename ny_gdp_mktp_kn GDP
rename sp_pop_totl pop
rename en_atm_co2e_kt CO2

gen Cpc = C/pop
gen GDPpc = GDP/pop
gen CO2pc = CO2/pop
 
label var Cpc   "Final consumption expenediture per capita (constant LCU)"
label var GDPpc "GDP per capita (constant LCU)"
label var CO2pc "CO2 kt per capita"

keep icode year Cpc GDPpc CO2p

save ".\data\xtcoint.dta", replace
*/


use ".\data\xtcoint.dta", clear

**********************************************
* Figure 14.8: Consumption and GDP per Capita
**********************************************

	set scheme s1mono
	xtline Cpc, overlay legend(off) xtitle("")
	*graph export ".\graphs\xtcointCpc.pdf", as(pdf) replace
	xtline GDPpc, overlay legend(off) xtitle("")
	*graph export ".\graphs\xtcointGDPpc.pdf", as(pdf) replace
	*graph close _all

* CSD test
	xtreg Cpc GDP, fe
	xtcsd, pesaran
	
* Cointegration tests
	xtcointtest pedroni Cpc GDPpc, lags(aic 5) ar(panelspecific) demean /* Demeaning gets rid of some CSD */
	xtcointtest pedroni Cpc GDPpc, lags(aic 5) ar(same)	demean

	xtcointtest kao Cpc GDPpc, lags(aic 5) demean 
	
	xtcointtest westerlund Cpc GDPpc, somepanels demean					
	xtcointtest westerlund Cpc GDPpc, allpanels demean					
	
* The results
	quietly xtreg Cpc GDP i.year, fe
		estimates store TimeFE
	quietly xtreg Cpc GDP, fe
		estimates store FE
	quietly xtscc Cpc GDP       , fe
		estimates store DKraay
	estimates table TimeFE FE DKraay , b(%7.3f) se(%7.3f) drop(i.year) 

	
